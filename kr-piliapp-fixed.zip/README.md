# PiliApp 로컬 스냅샷

기존 `kr.piliapp.com.zip`의 저장된 홈/목록 페이지를 로컬에서 열 수 있게 복구하고, 동전던지기와 주사위 도구를 추가한 로컬 웹사이트입니다.

## 실행

Python 3가 설치되어 있으면 프로젝트 폴더에서 다음 명령을 실행하세요.

```bash
python3 server.py
```

기본 주소는 <http://127.0.0.1:8000/> 입니다. 다른 포트를 쓰려면 `PORT=9000 python3 server.py`처럼 지정할 수 있습니다.

## 복구한 내용

- 저장된 HTML의 원본 사이트 강제 이동, 추적 및 광고 스크립트를 제거했습니다.
- 저장된 홈·전체 항목·교실 관리·임의 도구 페이지를 로컬 경로에서 제공합니다.
- 저장된 목록의 한국어 실시간 검색을 추가했습니다.
- 모바일 내비게이션과 카테고리 메뉴 동작을 복구했습니다. 주사위 메뉴는 참고 화면처럼 810×56px, #343a40 배경으로, 동전 메뉴는 1076×56px, #212529 배경으로 표시합니다. 주사위 메뉴의 브랜드·링크 글자 크기도 참고 이미지에 맞췄습니다.
- 도구 썸네일 지연 로딩을 복구했습니다.
- `/random/coin/`은 대기 중 일정 속도로 오른쪽으로 계속 회전하고, 던지는 동안에는 대기 회전을 멈춘 뒤 원본 cubic-bezier 감속으로 4초 동안 결과를 보여주고 다시 대기 회전을 시작합니다. 90개 테두리 세그먼트, 앞·뒷면 결과 전환, 시작·종료 효과음을 사용합니다. 모션·동전 그림·효과음은 모두 로컬 자산이며, 무작위 모드에는 암호학적 난수를 사용합니다. 로비의 기존 favicon은 유지하고, 동전 도구 탭에는 동전 아이콘을 표시합니다.
- `/random/dice/`는 참고 화면과 같은 메뉴·여백, 1~6개 선택, 3열 주사위 배열, 굴리기·개수 컨트롤, 설명 문단 및 주사위 이미지 표를 갖습니다. 3D CSS 주사위 본체를 참고 이미지와 같은 약 108px 크기로 맞췄으며, 굴리기 버튼·개수 선택기도 조금 확대했습니다. 6면은 두 줄에 점 3개씩 균일하게 배치하고 브라우저 탭에는 빨간 주사위 아이콘을 표시합니다. 3D CSS 주사위와 그림·효과음은 로컬 파일로 제공합니다. 동전 페이지 상단의 `주사위` 메뉴도 이 로컬 페이지로 연결됩니다.
- 관리자 설정은 `/admin/` 별도 페이지로 분리했으며, 일반 도구 페이지에는 관리자 버튼이나 설정이 표시되지 않습니다. `/admin/`은 생성된 비밀번호와 서버 세션으로 보호됩니다. 로그인 후 동전 모드와 주사위 합계를 모든 방문자에게 적용할 수 있습니다.
- 주사위는 무작위 합계 또는 특정 합계(1–36)를 관리자 패널에서 선택할 수 있습니다. 고정 합계가 선택된 경우 가능한 범위에 맞춰 주사위 개수를 자동 조정하며, 방문자 화면에는 별도 모드 안내를 표시하지 않습니다.
- 그 외 ZIP에 포함되지 않은 상세 도구 페이지는 공식 PiliApp 페이지로 이동시킵니다.

처음 서버를 실행하면 관리자 비밀번호가 터미널에 한 번 표시되고, 프로젝트 폴더의 `.admin-password`에 권한 제한 상태로 저장됩니다. 이 파일은 공유하거나 배포 ZIP에 넣지 마세요. 로그인은 8시간 후 만료되며 서버를 재시작하면 다시 로그인해야 합니다. 설정은 `coin-mode.json` 및 `dice-settings.json`에 저장됩니다.

ZIP에 포함된 홈/목록, 동전, 주사위, 관리자 페이지는 로컬 서버에서 제공합니다. 원본에 없는 다른 도구 링크는 공식 PiliApp 페이지로 이동합니다. 서버는 지정된 포트에서 `0.0.0.0`에 바인딩합니다.


## Render 배포

Render는 ZIP을 자동으로 풀지 않습니다. ZIP을 GitHub 저장소 **루트**에 `kr-piliapp-fixed.zip` 이름으로 올리고(또는 저장소에 이미 있는 `kr.piliapp.com.zip`의 내용을 최신 파일로 교체), 아래 Build Command를 설정하세요. `render.yaml`과 `render-persistent.yaml`에도 같은 압축 해제 명령을 넣었습니다.

```bash
python -c "import pathlib, zipfile; c=[pathlib.Path('kr-piliapp-fixed.zip'),pathlib.Path('kr.piliapp.com.zip')]; a=[p for p in c if p.is_file()]; a=a or sorted(pathlib.Path('.').glob('*.zip')); assert a, 'Add the deployment ZIP to the repository root'; zipfile.ZipFile(a[0]).extractall('.')" && pip install -r requirements.txt && python -m compileall -q server.py
```

이미 만든 Render 서비스를 업데이트할 때는 GitHub ZIP을 **교체**하고 커밋한 다음, Render 서비스의 **Settings → Build & Deploy → Build Command**에도 위 명령을 넣어 저장하세요. Start Command는 `python server.py`입니다. 그런 다음 **Manual Deploy → Clear build cache & deploy**를 실행하세요. 기존 Build Command가 `python -m compileall -q server.py`뿐이면 ZIP이 풀리지 않아 새 HTML·아이콘·모션이 적용되지 않습니다.

새 Blueprint를 만들 경우 무료 시험용 `render.yaml`을 사용하거나, 관리자 설정을 재시작·재배포 뒤에도 보존하려면 `render-persistent.yaml`을 저장소 루트의 `render.yaml`로 복사해 사용합니다. 배포 뒤 `/api/health`, `/random/coin/`, `/random/dice/`, `/admin/`을 확인하세요.

**저장 차이:** 기본 무료 Blueprint는 데이터 디렉터리를 임시 파일시스템에 두므로 서비스가 유휴 종료되거나 재시작·재배포되면 관리자 비밀번호 외에 저장한 동전 모드와 주사위 합계가 초기화될 수 있습니다. 저장 상태를 유지해야 하면 `render-persistent.yaml`을 선택하세요. 이 설정은 유료 웹 서비스와 1GB 영구 디스크를 사용하며, 디스크 비용은 Render 요금에 따라 별도로 발생할 수 있습니다.

Render는 웹 서비스를 `PORT` 환경변수와 `0.0.0.0`에 바인딩하도록 요구하며, 서버가 이를 지원합니다. 이 앱은 표준 Python 라이브러리만 사용합니다. 기본 빌드 명령과 호환되도록 배포 폴더에 빈 의존성 목록 `requirements.txt`도 포함되어 있습니다.
